import xbmc
import subprocess
subprocess.Popen('cmd /c start http://www.netflix.com')
if (__name__ == "__main__"):
    try:
        import AlphaUIUtils

        AlphaUIUtils.CloseLauncher()
    except:
        pass
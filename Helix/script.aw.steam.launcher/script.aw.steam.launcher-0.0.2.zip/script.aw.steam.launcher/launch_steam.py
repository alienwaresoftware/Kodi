import xbmc
import AlphaUIUtils

if (__name__ == "__main__"):

    AlphaUIUtils.LaunchSteam()

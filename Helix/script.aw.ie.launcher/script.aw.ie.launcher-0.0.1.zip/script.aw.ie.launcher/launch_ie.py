import xbmc
import subprocess
subprocess.Popen('cmd /c start iexplore.exe')
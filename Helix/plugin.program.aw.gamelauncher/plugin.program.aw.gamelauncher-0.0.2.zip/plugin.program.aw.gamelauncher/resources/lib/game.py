class Game(object):
    def __init__(self, gameId, title, type, thumbImage, fanartImage):
        self.gameId = gameId
        self.title = title
        self.type = type
        self.thumbImage = thumbImage
        self.fanartImage = fanartImage

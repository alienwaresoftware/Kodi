try:
    import AlphaUIUtils

    AlphaUIUtils.CloseLauncher()
except:
    pass
import zipfile, os, xbmc

if (__name__ == "__main__"):
    print("Now themes part of skin")
    
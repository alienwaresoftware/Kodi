import xbmc
import subprocess
subprocess.Popen('cmd /c start http://kodi.wiki/view/XBMC_Quick_Start_Guide')
from resources.lib import AlphaUIUtils

AlphaUIUtils.CloseLauncher()

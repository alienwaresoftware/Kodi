import xbmc
from resources.lib import AlphaUIUtils

AlphaUIUtils.SleepSystem()

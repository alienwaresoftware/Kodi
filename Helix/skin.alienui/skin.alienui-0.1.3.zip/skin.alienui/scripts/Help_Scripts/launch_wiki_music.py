import xbmc
import subprocess
subprocess.Popen('cmd /c start http://kodi.wiki/view/Adding_music_to_the_library')
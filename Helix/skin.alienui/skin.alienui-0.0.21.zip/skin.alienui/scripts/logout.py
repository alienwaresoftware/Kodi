import xbmc
import subprocess

subprocess.call(['shutdown', '-l'])

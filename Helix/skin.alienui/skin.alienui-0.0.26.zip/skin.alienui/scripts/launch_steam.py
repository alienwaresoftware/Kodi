import xbmc
import AlphaUIUtils

AlphaUIUtils.LaunchSteam()

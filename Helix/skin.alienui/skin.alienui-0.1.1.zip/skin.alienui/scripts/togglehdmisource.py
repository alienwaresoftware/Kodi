from resources.lib import AlphaUIUtils

AlphaUIUtils.ToggleHDMISource()
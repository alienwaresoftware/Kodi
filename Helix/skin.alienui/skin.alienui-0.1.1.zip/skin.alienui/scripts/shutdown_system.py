import xbmc
from resources.lib import AlphaUIUtils

AlphaUIUtils.ShutdownSystem()

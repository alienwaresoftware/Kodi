import xbmc
import AlphaUIUtils

AlphaUIUtils.SleepSystem()

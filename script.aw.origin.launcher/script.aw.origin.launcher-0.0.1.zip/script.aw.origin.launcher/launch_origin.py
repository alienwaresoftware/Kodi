import xbmc
import subprocess
subprocess.Popen('"C:\Program Files (x86)\Origin\Origin.exe"')
import xbmc
import subprocess
subprocess.Popen('cmd /c start http://www.youtube.com/leanback')
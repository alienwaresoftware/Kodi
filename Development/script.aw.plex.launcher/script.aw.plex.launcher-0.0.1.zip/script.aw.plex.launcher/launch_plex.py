import xbmc
import subprocess
subprocess.Popen('"C:\Program Files (x86)\Plex Home Theater\Plex Home Theater.exe"')
import xbmc
import subprocess
subprocess.Popen('"C:\Program Files (x86)\Ubisoft\Ubisoft Game Launcher\Uplay.exe"')
import zipfile
zfile = zipfile.ZipFile('http://raw.github.com/alienwaresoftware/Kodi/master/Backgrounds.zip')
zfile.extractall("C:\Alienware)
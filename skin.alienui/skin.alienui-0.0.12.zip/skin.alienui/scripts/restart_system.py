import xbmc
import AlphaUIUtils

AlphaUIUtils.RestartSystem()

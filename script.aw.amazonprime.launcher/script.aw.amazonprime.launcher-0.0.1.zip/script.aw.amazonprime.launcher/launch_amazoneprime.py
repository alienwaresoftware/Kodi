import xbmc
import subprocess
subprocess.Popen('cmd /c start http://www.amazon.com/Prime-Instant-Video/b?node=2676882011')
import xbmc
import subprocess
subprocess.Popen('"C:\Program Files (x86)\Battle.net\Battle.net Launcher.exe"')